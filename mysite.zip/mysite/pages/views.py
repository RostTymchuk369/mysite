from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def home(request):
    context = {
        'title': 'Главная страница',
        'flatpage': {
            'content': 'Добро пожаловать на наш сайт! Здесь вы найдете интересную информацию и полезные ресурсы.'
        }
    }
    return render(request, 'home.html', context)

def about(request):
    context = {
        'title': 'О нас',
        'content': 'Мы - команда профессионалов, создающих качественные веб-решения.'
    }
    return render(request, 'about.html', context)

@login_required
def admin_only(request):
    context = {
        'title': 'Административная панель',
        'user': request.user,
    }
    return render(request, 'admin_only.html', context)
